# Data-Warehousing

# File-1 Create_Emp_Staging.Sql


# This File contains all Create table statements and all Alter Contraints statements which are used to create staging table.

# File-2 Staging Queries.Sql

# This file contains all select statments which were used to load into staging table from CSV file.

# File-3 CSV File

# Preview of exported data from database to CSV file.

# File- 4 Assignment 2.docx

# It is technical design document which contains all the information regarding this assignments.

# Package 1
# Script for export of Emp table to CSV

# Package 2
# Script for importing to staging table
